import React from "react";

const VideoFile = () => {
return <div>VideoFile</div>;
};

export default VideoFile;