import { LaptopWindows } from '@material-ui/icons';
import ReactPlayer from 'react-player'

import { useLocation } from "react-router-dom";

const location = userlocation();
console.log(location);
class window extends React.Component{

    render() {

        return (

      <ReactPlayer
        className="react-player"
        url={url}
        width="100%"
        height="100%"
        muted={true} //chrome정책으로 인해 자동 재생을 위해 mute 옵션을 true로 해주었다.
        playing={true}
        controls={true}
        loop={true} 
      />
    
    
    

        );
      }
} 

export default window;